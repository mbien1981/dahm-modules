return DMod:new("spectator_camera_fov", {
	name = "Spectator camera fov",
	author = "_atom",
	categories = { "gameplay", "QoL" },
	includes = {
		{ "mod_localization", { type = "localization" } },
		{ "mod_options", { type = "menu_options" } },
		{ "mod_hooks" },
	},
})
