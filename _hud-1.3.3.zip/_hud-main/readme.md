**Requirements**: 
https://steamcommunity.com/groups/dahm4pd/discussions/3/490123197956419203/
https://github.com/mbien1981/_sdk

**Installation**: Drop _hud folder inside of `mods/`