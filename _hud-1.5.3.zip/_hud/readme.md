**Requirements**: 
https://steamcommunity.com/groups/dahm4pd/discussions/3/490123197956419203/

**Installation**: Drop _hud folder inside of `mods/`