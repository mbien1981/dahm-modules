# Requirements
- [DAHM 1.16.15x or above with the hud module enabled.](https://steamcommunity.com/groups/dahm4pd/discussions/3/490123197956419203/)

# Installation
* Drop the `_hud` folder inside of `mods/`

# Compatibility
* `_hud` may present compatibility issues with other hud mods such as [WTFBM](https://modworkshop.net/mod/19303), there is no plans to make _hud  compatible with such hud mods.

# Credits
* [neonsynth](https://steamcommunity.com/profiles/76561198844370238/) - German Localization
