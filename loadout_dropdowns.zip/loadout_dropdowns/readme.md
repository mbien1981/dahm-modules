# Requirements
* [DAHM/DorHud](https://steamcommunity.com/groups/dahm4pd) 1.16.1.1 or above.

# Installation
Drop the PDTH-Loadout-Dropdowns folder inside of your `mods/` directory

# Usage
Select your kit menu node and press Intro or click on the white text next to the multi-choice buttons and the dropdown should popup

# Preview
![](https://i.imgur.com/wnN375z.png)